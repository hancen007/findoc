print("ddd")
def ddd():
    pass
