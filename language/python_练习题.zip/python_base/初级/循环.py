i = 1
while i <10:
    print("%d" %i)
    i = i + 1

#break结束整个while循环
i = 1
while i <5:
    print("------")
    if i ==3:
        break
    print(i)
    i +=1
#
i = 1
