class Test (object):
    def __init__(self):
        self.__num = 100
    @property
    def num(self):
        print("-----getter----")
        return self.__num

    @num.setter
    def num(self,newNum):
        return self.__num

t =Test()
t.num = 20
print(t.num)
