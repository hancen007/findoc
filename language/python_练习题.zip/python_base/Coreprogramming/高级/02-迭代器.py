from collections import Iterable
#迭代器
from collections import Iterator


isinstance([],Iterable)
