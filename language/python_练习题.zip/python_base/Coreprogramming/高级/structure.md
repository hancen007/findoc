##	自动化测试工具分类
UI自动化工具：QTP（容易掌握价格偏高，目前用得最广的）、Selenium、RFT
移动端自动化工具：SikMobile、Aappium
接口自动化工具：Jmeter、Request

| 分类 | 工具 | 说明 |
| ---- | ---- | ---- |
|      |      |      |
|      |      |      |
|      |      |      |
